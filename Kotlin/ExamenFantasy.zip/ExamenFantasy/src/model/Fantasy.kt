package model

class Fantasy(id:Int, nombre:String, valor:Int,  posicion:String, conjuntoJugadores:ArrayList<Jugador>, var conjuntoJugadoresFichar: ArrayList<Jugador>) {




}