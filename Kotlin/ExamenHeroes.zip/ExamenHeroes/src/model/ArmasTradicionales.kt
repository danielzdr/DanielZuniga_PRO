package model

class ArmasTradicionales(id:Int, nombre:String, nivelPotencia:Int,nivelDanio:Int, var peso:Int):
    Armas(id,nombre,nivelPotencia,nivelDanio) {

}