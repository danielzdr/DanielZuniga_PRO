package com.example.miprimeraapp


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.miprimeraapp.navigation.AppNavigation
import com.example.miprimeraapp.theme.MiPrimeraAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MiPrimeraAppTheme {
                AppNavigation()
            }
        }
    }
}