package RellenarForm.utils;

public class UltimoDigitoNoLetraException extends RuntimeException {
    public UltimoDigitoNoLetraException(String message) {
        super(message);
    }
}
