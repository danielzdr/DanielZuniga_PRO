package RellenarForm.utils;

public class LongitudDNINoValidaException extends RuntimeException {
    public LongitudDNINoValidaException(String message) {
        super(message);
    }
}
