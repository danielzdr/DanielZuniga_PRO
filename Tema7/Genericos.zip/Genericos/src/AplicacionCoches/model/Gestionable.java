package AplicacionCoches.model;

public interface Gestionable {
}
