package Ejercicio9Casa.model;

public class CasaException extends RuntimeException {
  public CasaException(String message) {
    super(message);
  }
}
