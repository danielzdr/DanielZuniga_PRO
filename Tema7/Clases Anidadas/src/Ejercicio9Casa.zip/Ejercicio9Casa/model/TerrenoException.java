package Ejercicio9Casa.model;

public class TerrenoException extends RuntimeException {
    public TerrenoException(String message) {
        super(message);
    }
}
