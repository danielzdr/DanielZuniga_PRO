package model;

public interface Descargable {
    public int calcularTiempoDescarga(double vel);

    public double obtenerTamanioGB();
}
