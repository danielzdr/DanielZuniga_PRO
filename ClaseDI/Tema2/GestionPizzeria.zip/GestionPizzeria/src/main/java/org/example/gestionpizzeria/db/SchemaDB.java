package org.example.gestionpizzeria.db;

public interface SchemaDB {

    String DB_NAME="pizzeria";
    String TAB_NAME="pedidos";
    String COL_ID="";
    String COL_NAME="nombre";
    String COL_TELF="telefono";
    String COL_PIZZA="pizza";
    String COL_TAMAÑO="tamaño";
    String COL_PRECIO="precio";
}
