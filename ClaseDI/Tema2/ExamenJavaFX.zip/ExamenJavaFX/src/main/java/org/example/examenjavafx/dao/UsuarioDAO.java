package org.example.examenjavafx.dao;

import org.example.examenjavafx.model.Usuarios;

import java.util.List;

public interface UsuarioDAO {

    List<Usuarios> obtenerUsuarios();

}
