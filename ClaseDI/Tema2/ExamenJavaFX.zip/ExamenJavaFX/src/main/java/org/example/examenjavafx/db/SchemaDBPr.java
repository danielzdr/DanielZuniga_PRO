package org.example.examenjavafx.db;

public interface SchemaDBPr {
    String DB_NAME="tienda";
    String TAB_NAME= "productos";
    String COL_ID="id";
    String COL_NAME="nombre";
    String COL_CATEGORIA="categoria";
    String COL_PRECIO="precio";
    String COL_DESCRIP="descripcion";
}
