package org.example.examenjavafx.db;

public interface SchemaDB {

    String DB_NAME="tienda";
    String TAB_NAME= "usuarios";
    String COL_ID="id";
    String COL_NAME="nombre";
    String COL_MAIL="correo";
    String COL_PASS="password";
}
