import java.util.Scanner;

public class Ejercicio2 {
        static Scanner lectorTeclado=new Scanner(System.in);
    public static void main (String []args){

        int numero=(int)(Math.random()*9000)+1000;
        System.out.println("Introduce un numero entre el 1000 y 9999: ");
        numero = lectorTeclado.nextInt();

        int unidades=(numero/1000);
        boolean condicion1= false;
        System.out.println("Has acertado las unidades "+unidades+condicion1);
        int decenas= numero/100;
        System.out.println("Has acertado las decenas "+decenas);
        int centenas=numero/10;
        System.out.println("Has acertado las centenas "+centenas);
        int millares=numero/1;
        System.out.println("Has acertado los millares "+millares);

        int condicion=((millares/1000) + (centenas/ 100) + (decenas/ 10) + (unidades/1));



    };

}
