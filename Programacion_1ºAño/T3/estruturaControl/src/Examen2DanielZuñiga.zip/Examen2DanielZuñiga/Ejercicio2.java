package Examen2DanielZuñiga;

import java.util.Scanner;

public class Ejercicio2 {
    static Scanner lectorTeclado = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Introduce un numero: ");
        int numero = lectorTeclado.nextInt();
        System.out.print("Introduce un número entre 1 y 100: ");
        int numeroUsuario = lectorTeclado.nextInt();

        for (int i = 0; i < 100; i++) {


            int numeroAleatorio = (int) (Math.random() * 100);
        }





    }
}
