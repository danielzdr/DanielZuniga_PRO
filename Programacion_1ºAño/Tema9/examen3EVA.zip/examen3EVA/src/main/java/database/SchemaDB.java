package database;

public interface SchemaDB {
public String TAB_PROFESOR= "profesor";
public String COL_NOMBRE= "nombre";
public String COL_DNI= "DNI";
public String COL_SALARIOBASE="salarioBase";
}
