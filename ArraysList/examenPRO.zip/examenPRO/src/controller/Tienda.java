package controller;

import model.Bici;
import model.Moto;
import model.Patinete;
import model.Vehiculo;

import java.util.ArrayList;
import java.util.Scanner;

public class Tienda {
        protected ArrayList<Vehiculo> stock;
        protected double caja;


        public Tienda() {
            this.stock = new ArrayList<>();
            this.caja = 0;
        }



        public void agregarVehiculo(Scanner scanner , Vehiculo vehiculo , Moto moto , Bici bici , Patinete patinete) {
            stock.add(vehiculo);
            System.out.println("Vehículo agregado: " + vehiculo.getMarca() + " " + vehiculo.getModelo());
        }

        public Vehiculo buscarPorNumeroSerie(Scanner scanner , String numeroSerie) {
            for (Vehiculo vehiculo : stock) {
                if (vehiculo.getnumeroSerie().equals(numeroSerie)) {
                    return vehiculo;
                }
            }
            System.out.println("Vehículo no encontrado.");
            return null;
        }


        public void venderVehiculo(Scanner scanner, String numeroSerie) {
            Vehiculo vehiculo = buscarPorNumeroSerie(scanner , numeroSerie);
            if (vehiculo != null) {
                vehiculo.vender();
                stock.remove(vehiculo);
            }
        }


        public void repararVehiculo(Scanner scanner , String numeroSerie) {
            Vehiculo vehiculo = buscarPorNumeroSerie(scanner , numeroSerie);
            if (vehiculo != null) {
                vehiculo.reparar();
            }
        }


        public void verCaja() {
            System.out.println("Caja actual= " + caja);
        }


        public void mostrarStock() {
            for (Vehiculo vehiculo : stock) {
                vehiculo.mostrarDatos();
            }
        }
}
