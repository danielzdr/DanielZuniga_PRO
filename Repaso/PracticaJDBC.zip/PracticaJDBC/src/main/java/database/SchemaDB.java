package database;

public interface SchemaDB {
    public static final String TAB_COCHES="coches";
    public static final String COL_ID="id";
    public static final String COL_MARCA="marca";
    public static final String COL_MODELO="modelo";
    public static final String COL_MATRICULA="matricula";
    public static final String COL_COLOR="color";
    public static final String COL_PRECIO="precio";
    public static final String TAB_PASAJEROS="pasajeros";
    public static final String COL_NOMBRE="nombre";
    public static final String COL_EDAD="edad";
    public static final String COL_PESO="peso";
}
