package model;

public interface serializable {
    static final long serialVersionUID = 1L;
}
