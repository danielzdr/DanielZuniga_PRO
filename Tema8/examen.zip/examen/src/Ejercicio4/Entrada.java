package Ejercicio4;

import Ejercicio4.modelEjercicio4.Inventario;

public class Entrada {
    public static void main(String[] args)  {
        try {

        }catch (NullPointerException e) {
            Inventario<Inventario.Producto> listaProductos = null;
            Inventario.Producto inventario = new Inventario.Producto();
            Inventario.Producto producto = new Inventario.Producto("Pollo" , 100.50 , 5);
            Inventario.Producto producto2 = new Inventario.Producto("Pescado" , 10.70 , 10);
            Inventario.Producto producto3 = new Inventario.Producto("Arroz" , 4.25 , 9);

            listaProductos.agregarElemento(producto);
            listaProductos.agregarElemento(producto2);
            listaProductos.agregarElemento(producto3);

            listaProductos.mostrarInventario();
            System.out.println("Error de inicializacion");
        }finally {
            System.out.println("Error de acabado");
        }


    }
}
