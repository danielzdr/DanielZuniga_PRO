package EjerciciosDel1al3.model;

public interface Serializable {

}
