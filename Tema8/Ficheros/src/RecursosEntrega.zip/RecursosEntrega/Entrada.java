package RecursosEntrega;

import java.io.File;

public class Entrada {
    public static void main(String[] args) {
        OperacionesFichero operacionesFichero= new OperacionesFichero();
        operacionesFichero.leerInformacion(new File("C:\\1ºDAM\\Programacion"));

    }
}
